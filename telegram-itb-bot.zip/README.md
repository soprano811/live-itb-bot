
# Telegram ITB Bot for Railway

## Запуск на Railway
1. Создай новый проект на [https://railway.app](https://railway.app)
2. Загрузи содержимое этого архива
3. Всё готово — бот запустится и отправит сообщение в Telegram
